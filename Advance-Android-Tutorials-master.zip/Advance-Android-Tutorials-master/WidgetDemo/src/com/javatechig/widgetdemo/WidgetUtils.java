package com.javatechig.widgetdemo;

public class WidgetUtils {
	final static String WIDGET_UPDATE_ACTION ="com.javatechig.intent.action.UPDATE_WIDGET";
}
