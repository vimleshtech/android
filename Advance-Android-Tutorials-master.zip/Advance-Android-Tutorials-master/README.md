1. **Sending SMS in android Example**
    http://javatechig.com/android/sending-sms-message-in-android/
2. **Android JSON Feed Reader**
    http://javatechig.com/android/json-feed-reader-in-android/
3. **Asynchronous image downloader**
    http://javatechig.com/android/download-image-using-asynctask-in-android/
4. **Asynchronous image loading list**
    http://javatechig.com/android/asynchronous-image-loader-in-android-listview/
5. **Android app widget example**
    http://javatechig.com/android/app-widgets-example-in-android/ 
